public class Next_Level {
    private int currentLevel;
    static int maxLevel = 5;
    
    public Next_Level() {
        this.currentLevel = 1;
    }
    
    public void startNewLevel() {
    	if (currentLevel == maxLevel-1) 
            System.out.println("You're at the final level! Level " + currentLevel);
    	else if (currentLevel < maxLevel)
    		System.out.println("Starting Level " + currentLevel);
    	System.out.println();
        // Add code here to initialize the level, spawn enemies, set up obstacles, etc.
        
    }
    
    public void completeLevel() {
    	if (currentLevel == maxLevel-1) {
    		System.out.println("Congratulations! You win the game");
    		System.out.println();
    		System.exit(currentLevel);
    	}
    	else if (currentLevel < maxLevel) {
            System.out.println("Congratulations! You have completed Level " + currentLevel);
            System.out.println();
            currentLevel++;
    	}
    }
    
    public static void main(String[] args) {
        Next_Level game = new Next_Level();   
        for (int i = 0; i < maxLevel; i++) {
            game.startNewLevel();
            
            game.completeLevel();
        }
    }
}